import cv2
import numpy as np

def create_aruco_sheet():
    # 1. A4 용지 규격 설정 (300 DPI 기준 픽셀 크기: 2480 x 3508)
    a4_w, a4_h = 2480, 3508
    sheet = np.ones((a4_h, a4_w), dtype=np.uint8) * 255 # 흰색 배경

    # 2. ArUco 딕셔너리 설정 (4X4 마커, 50개 용량의 DICT_4X4_50 사용)
    aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)

    # 3. 원하는 마커의 실제 출력 크기 설정 (단위: mm)
    # 가로세로 50mm(5cm) 크기의 마커로 설정
    marker_size_mm = 50 
    
    # mm를 300 DPI 기준 픽셀 크기로 변환 (1인치 = 25.4mm = 300픽셀)
    pixel_size = int((marker_size_mm * 300) / 25.4)

    # 4. 생성할 마커 ID 목록 (0번부터 7번까지 총 8개)
    marker_ids = list(range(8))
    
    # 배치를 위한 여백 및 간격 설정 (픽셀 단위)
    margin_top = 250   # 상단 여백
    margin_side = 350  # 좌우 여백
    spacing_x = 400    # 열(Column) 간격
    spacing_y = 180    # 행(Row) 간격

    # 2열 4행 구조로 배치 계산
    cols = 2

    for i, marker_id in enumerate(marker_ids):
        # 현재 마커가 배치될 행(row)과 열(col) 인덱스 계산
        row = i // cols
        col = i % cols

        # 4X4 개별 마커 이미지 생성
        marker_img = cv2.aruco.generateImageMarker(aruco_dict, marker_id, pixel_size)
        
        # 외곽선을 쉽게 자를 수 있도록 연한 회색(값: 220) 가이드 테두리 추가
        marker_with_border = cv2.copyMakeBorder(marker_img, 2, 2, 2, 2, cv2.BORDER_CONSTANT, value=220)
        p_size = pixel_size + 4

        # 각 마커의 시작 x, y 픽셀 좌표 계산
        x_start = margin_side + col * (p_size + spacing_x)
        y_start = margin_top + row * (p_size + spacing_y)

        # A4 도화지에 마커 이미지 합성
        sheet[y_start:y_start+p_size, x_start:x_start+p_size] = marker_with_border
        print(f"ID {marker_id} (4X4) 배치 완료 -> {row+1}행 {col+1}열 (크기: 약 {marker_size_mm}x{marker_size_mm} mm)")

    # 5. 최종 이미지 파일 저장
    output_filename = 'aruco_4x4_0to7_sheet.png'
    cv2.imwrite(output_filename, sheet)
    print(f"\n★★★ {output_filename} 파일이 성공적으로 생성되었습니다! ★★★")

if __name__ == '__main__':
    create_aruco_sheet()