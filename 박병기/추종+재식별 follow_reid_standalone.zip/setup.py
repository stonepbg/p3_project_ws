from setuptools import setup

package_name = "follow_reid_standalone"

setup(
    name=package_name,
    version="1.0.0",
    packages=[package_name],
    data_files=[
        ("share/ament_index/resource_index/packages",
            ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="ws",
    maintainer_email="you@example.com",
    description="사람 추종 + CLIP Re-ID 단독 버전 (참고용)",
    license="MIT",
    entry_points={
        "console_scripts": [
            "follow_node = follow_reid_standalone.follow_node:main",
        ],
    },
)
