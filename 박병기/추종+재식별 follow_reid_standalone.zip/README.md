# follow_reid_standalone

사람 한 명을 락(lock)해서 따라가는 **추종 + Re-ID** 단독 노드입니다.
팀 프로젝트(리테일/창고 모바일 매니퓰레이터)의 `follow_node`에서
**추종에 필요한 부분만** 떼어낸 참고용 코드입니다.

```
RealSense D435 ──> YOLO11n(사람 검출) ──> CLIP Re-ID(락/재락) ──> /target_cmd
                                                              └─> MJPEG 스트림(8080)
```

블록·레이저·후방감시·FSM 연동은 **전부 제거**했습니다.
"가장 가까운 사람을 잡아서, 놓쳐도 같은 사람을 다시 알아보고 따라간다"만 남았습니다.

---

## 1. 무엇이 필요한가

| 항목 | 내용 |
|------|------|
| ROS2 | Humble 이상 (rclpy) |
| 카메라 | RealSense D435 (depth로 거리 측정) |
| GPU | **강력 권장.** CLIP Re-ID는 무거워서 GPU 없으면 매우 느립니다 |
| 모델 | 자동 다운로드 (아래 참고 — 별도 전달 불필요) |

> ⚠️ **CPU-only / 저사양 보드 주의**
> CLIP-ReID(ViT 백본)는 데스크톱 GPU 기준 모델입니다.
> GPU가 없는 SBC에서는 프레임당 수 초가 걸려 실시간 추종이 어렵습니다.
> 그런 환경이면 아래 "개조 포인트"의 **경량 트래커 교체**를 참고하세요.

---

## 2. 모델 파일 — 별도 다운로드 불필요 (자동)

**모델 파일을 따로 받을 필요가 없습니다.** 둘 다 첫 실행 때 자동으로 받아집니다.

- `yolo11n.pt` : ultralytics가 자동 다운로드
- `clip_msmt17.pt` : **BoxMOT가 자동 다운로드** (약 488MB, 첫 실행 시 1회)

`follow_node.py`의 `REID_PATH = "clip_msmt17.pt"` 처럼 **파일명만** 지정돼 있으면,
BoxMOT가 해당 파일이 없을 때 알아서 내려받습니다. 인터넷 연결만 있으면 됩니다.

> 참고: BoxMOT가 자동 다운로드로 제공하는 Re-ID 모델들
> - **무거움(정확)**: `clip_msmt17.pt`, `clip_market1501.pt`
> - **가벼움(빠름)**: `osnet_x0_25_msmt17.pt`(약 3MB), `lmbn_n_cuhk03_d.pt`
>
> 저사양 보드면 `REID_PATH`를 `osnet_x0_25_msmt17.pt`로 바꾸면 훨씬 빠릅니다.

---

## 3. 설치

```bash
# 1) torch 먼저 (본인 환경에 맞게!)
#    GPU:  pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
#    CPU:  pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu

# 2) 나머지 의존성
pip install -r requirements.txt

# 3) ROS2 워크스페이스에 넣고 빌드
cd ~/your_ws
colcon build --packages-select follow_reid_standalone --symlink-install
source install/setup.bash
```

---

## 4. 실행

```bash
# GPU 사용 (기본)
ros2 run follow_reid_standalone follow_node

# CPU 강제 (느림, 테스트용)
REID_DEVICE=cpu ros2 run follow_reid_standalone follow_node
```

**화면 확인:** 브라우저에서 `http://<보드-IP>:8080/stream`
(예: `http://192.168.0.50:8080/stream`)

> 브라우저 탭은 하나만. MJPEG 서버는 동시 접속을 잘 못 받습니다.

---

## 5. 출력 토픽 — 이걸 AGV가 구독하면 됩니다

**`/target_cmd`** (`geometry_msgs/Twist`)

| 필드 | 의미 |
|------|------|
| `linear.z` | 모드: **0**=추종, **1**=좌탐색, **2**=우탐색, **3**=정지 |
| `linear.x` | 타겟까지 거리 (m) |
| `angular.z` | 좌우 조향 각도 (rad, +면 좌회전) |

AGV 쪽에서 이 값을 받아 바퀴 속도로 변환하면 됩니다.
예: `linear.z==0`이면 `linear.x`(거리)로 전진량, `angular.z`(각도)로 회전량 결정.

**입력 토픽 (선택):** `/follow_enable` (`std_msgs/Bool`) — 추종 on/off. 안 보내도 기본 on.

---

## 6. 동작 원리 (핵심만)

1. **최초 락**: 가장 가까운 사람을 타겟으로 잡고, 그 사람의 **CLIP 임베딩 + 색상 지문**을 저장.
2. **추종**: 락된 track_id를 따라가며 거리/각도를 `/target_cmd`로 발행.
3. **놓침(UNLOCK)**: 타겟 track이 사라지면 임베딩은 유지한 채 재식별 대기.
4. **재락(RELOCK)**: 다시 나타난 후보들의 임베딩을 저장된 것과 비교.
   - **3중 게이트**로 타인을 거름: **방향**(나간 쪽 반대에서 오면 타인) + **거리**(마지막 거리와 크게 다르면 타인) + **색상**.
   - 5프레임 연속 통과해야 실제 재락(순간 튐 방어).
5. **핵심 철학**: *확신이 없으면 아무도 안 잡고 멈춘다.* 엉뚱한 사람을 따라가느니 서 있는 게 낫다.

---

## 7. 개조 포인트 (본인 환경에 맞추기)

**카메라가 RealSense가 아니면**
`follow_node.py`의 `pyrealsense2`(`self.pipeline`, `median_depth`) 부분을 교체하세요.
depth가 없는 일반 웹캠이면, 거리(`dist`)를 **박스 높이로 근사**하면 됩니다
(사람이 가까울수록 박스가 큼). `median_depth`를 `box_height→거리` 함수로 바꾸세요.

**GPU가 없어서 CLIP이 너무 느리면**
`create_tracker`의 `tracker_type="deepocsort"` + CLIP 대신,
`tracker_type="bytetrack"`(Re-ID 없음, 매우 가벼움)으로 바꾸면 실시간이 됩니다.
단, 완전 가림 후 재식별 능력은 포기하게 됩니다.
(가벼운 Re-ID를 원하면 `REID_PATH`를 `"osnet_x0_25_msmt17.pt"`로 교체 — 3MB, 자동 다운로드, 훨씬 빠름)

**임계값 튜닝**
`__init__`의 `REID_SIM_THRESH`, `OSNET_STRONG`, `COLOR_SIM_THRESH`,
`DIST_GATE`, `SIDE_MARGIN`이 게이트 민감도입니다. 환경에 맞게 조정하세요.
(현재 값은 msmt17 CLIP + 실내 실측 기준)

---

## 8. 라이선스 / 출처

- YOLO11: Ultralytics (AGPL-3.0)
- BoxMOT / DeepOCSORT / CLIP-ReID: 각 원저작권 확인 요망
- 이 통합 코드: 팀 캡스톤 프로젝트 파생, 참고용
