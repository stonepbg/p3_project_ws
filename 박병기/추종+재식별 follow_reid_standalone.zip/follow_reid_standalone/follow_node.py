#!/usr/bin/env python3
# =====================================================================
#  follow_node.py  (추종 전용 단독 버전)
# ---------------------------------------------------------------------
#  RealSense D435 -> YOLO11n(사람 검출) -> CLIP Re-ID(락/재락) -> /target_cmd
#  화면은 MJPEG 스트림(http://<ip>:8080/stream)으로 확인.
#
#  원본(팀 프로젝트)에서 아래 기능은 제거했습니다:
#    - 블록/레이저 인식, 픽업 좌표 발행
#    - 후방 감시(안내모드), FSM 모드 연동
#  즉 "가장 가까운 사람 1명을 락해서 따라가는" 핵심만 남긴 참고용 코드입니다.
#
#  ▶ 모델은 .engine(TensorRT) 대신 .pt 를 사용합니다 (GPU 없이도 로드 가능).
#    - yolo11n.pt           : ultralytics가 자동 다운로드하거나 models/에 두면 됨
#    - clip_msmt17.pt       : 별도 전달받아 models/ 에 넣으세요 (약 488MB)
#
#  ▶ /target_cmd (geometry_msgs/Twist) 로 추종 명령을 발행합니다:
#      linear.z = 모드 (0=추종, 1=좌탐색, 2=우탐색, 3=정지)
#      linear.x = 타겟까지 거리(m)
#      angular.z = 좌우 조향 각도(rad)
#    동료분의 AGV가 이 토픽을 구독해서 움직이면 됩니다.
# =====================================================================
import os
import time
import math
import threading
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np
import cv2
import pyrealsense2 as rs
from ultralytics import YOLO
from boxmot.trackers.tracker_zoo import create_tracker, get_tracker_config

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Bool, Float32

PKG_DIR = os.path.dirname(os.path.abspath(__file__))

# ===== 모델 경로 =====
#  .pt 파일을 이 스크립트와 같은 폴더나 models/ 에 두세요.
YOLO_PATH = os.path.join(PKG_DIR, "yolo11n.pt")           # 없으면 ultralytics가 자동 다운로드
REID_PATH = "clip_msmt17.pt"

# ===== 실행 디바이스 =====
#  GPU가 있으면 "cuda:0", 없으면 "cpu".  (CPU면 매우 느립니다 - 참고용)
DEVICE = os.environ.get("REID_DEVICE", "cuda:0")
USE_HALF = DEVICE.startswith("cuda")   # FP16은 GPU에서만

# ===== 카메라/화각 파라미터 =====
CENTER_X = 320
IMG_WIDTH = 640
IMG_HEIGHT = 480
HFOV_DEG = 69.0            # RealSense D435 컬러 수평 화각
LOCK_FRAMES = 15          # 워밍업 프레임
LOST_DELAY = 8            # 사람 사라진 후 이 프레임 지나야 탐색 시작
FIND_HOLD_SEC = 0.5       # 재발견 시 정지 유지 시간

# ===== /target_cmd linear.z 모드 플래그 =====
MODE_FOLLOW = 0.0
MODE_SEARCH_LEFT = 1.0
MODE_SEARCH_RIGHT = 2.0
MODE_FIND = 3.0

# ============================================================
#  MJPEG 스트림 서버 (화면 확인용)  ->  http://<ip>:8080/stream
# ============================================================
_stream_frame = None
_stream_lock = threading.Lock()


class _MjpegHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def do_GET(self):
        if self.path != "/stream":
            self.send_response(404)
            self.end_headers()
            return
        self.send_response(200)
        self.send_header("Content-Type",
                         "multipart/x-mixed-replace; boundary=frame")
        self.end_headers()
        try:
            while True:
                with _stream_lock:
                    frame = _stream_frame
                if frame is not None:
                    ok, buf = cv2.imencode(
                        ".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 70])
                    if ok:
                        data = buf.tobytes()
                        self.wfile.write(b"--frame\r\n")
                        self.wfile.write(b"Content-Type: image/jpeg\r\n\r\n")
                        self.wfile.write(data)
                        self.wfile.write(b"\r\n")
                time.sleep(0.1)
        except Exception:
            pass


def _start_stream_server(port=8080):
    srv = ThreadingHTTPServer(("0.0.0.0", port), _MjpegHandler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()


# ============================================================
#  간단한 브래킷 박스 그리기 (오버레이용)
# ============================================================
def draw_fancy_box(img, x1, y1, x2, y2, label, color,
                   thickness=2, filled_label=False):
    L = max(15, int((x2 - x1) * 0.18))
    cv2.rectangle(img, (x1, y1), (x2, y2), color, 1, cv2.LINE_AA)
    for (px, py, dx, dy) in [(x1, y1, 1, 1), (x2, y1, -1, 1),
                             (x1, y2, 1, -1), (x2, y2, -1, -1)]:
        cv2.line(img, (px, py), (px + dx * L, py), color, thickness, cv2.LINE_AA)
        cv2.line(img, (px, py), (px, py + dy * L), color, thickness, cv2.LINE_AA)
    (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
    ly = max(y1 - 8, th + 6)
    if filled_label:
        cv2.rectangle(img, (x1, ly - th - 6), (x1 + tw + 10, ly + 2),
                      color, -1, cv2.LINE_AA)
        txt_color = (255, 255, 255)
    else:
        txt_color = color
    cv2.putText(img, label, (x1 + 5, ly - 3),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, txt_color, 1, cv2.LINE_AA)


class FollowNode(Node):
    def __init__(self):
        super().__init__("follow_node")
        self.cmd_pub = self.create_publisher(Twist, "/target_cmd", 10)
        self.cam_health_pub = self.create_publisher(Float32, "/cam_health", 10)
        # /follow_enable 로 추종 on/off (기본 on). 없어도 동작합니다.
        self.enable_sub = self.create_subscription(
            Bool, "/follow_enable", self.on_follow_enable, 10)
        self.enabled = True

        # ===== YOLO (사람 검출) =====
        self.get_logger().info(f"loading YOLO... ({YOLO_PATH})")
        self.model = YOLO(YOLO_PATH, task="detect")

        # ===== Re-ID 트래커 (DeepOCSORT + CLIP-ReID) =====
        _reid_w = Path(REID_PATH)
        self.get_logger().info(f"loading Re-ID... ({_reid_w}) device={DEVICE}")
        self.tracker = create_tracker(
            tracker_type="deepocsort",
            tracker_config=get_tracker_config("deepocsort"),
            reid_weights=_reid_w,
            device=DEVICE,
            half=USE_HALF,
        )
        # 화면 이탈 후 재등장 대비: ID 유지 강화
        self.tracker.max_age = 300
        self.tracker.min_hits = 2
        self.reid = self.tracker.model   # get_features(xyxys, img) -> (N, D)

        # ===== 락 / 재락 상태 =====
        self.locked_id = None
        self.locked_feat = None       # 저장된 타겟 임베딩
        self.locked_hist = None       # 타겟 HSV 색상 지문
        self.has_locked_once = False  # 최초 1회 락 이후 자동 락 금지
        self._relock_cand_id = None
        self._relock_streak = 0
        self.RELOCK_STREAK = 5        # 연속 PASS 프레임 (순간 튐 방어)
        self._relock_count = 0
        self._unlock_count = 0

        # ===== Re-ID 임계값 (msmt17 CLIP 기준, 실측 튜닝값) =====
        self.REID_SIM_THRESH = 0.28   # 재락 코사인 유사도 임계값
        self.OSNET_STRONG = 0.78      # 이 이상이면 색상 게이트 면제
        self.REID_EMA = 0.9           # 임베딩 EMA 계수
        self.EMA_UPDATE_GATE = 0.5    # EMA 갱신 게이트(오염 방지)
        self.COLOR_SIM_THRESH = 0.5   # 색상 게이트 통과 임계값
        self.COLOR_EMA = 0.9

        # ===== 공간 게이트 (가림-진입 타인 방어) =====
        self.SIDE_MARGIN = 80         # 방향 게이트 여유(px)
        self.DIST_GATE = 0.8          # 허용 거리차(m)
        self.OCC_CX_MARGIN = 150      # 가림 판정 x근접(px)
        self.OCC_DIST_MARGIN = 1.0    # 가림 판정 거리근접(m)
        self.occlusion_blacklist = set()

        # ===== RealSense =====
        self.pipeline = rs.pipeline()
        config = rs.config()
        config.enable_stream(rs.stream.color, IMG_WIDTH, IMG_HEIGHT,
                             rs.format.bgr8, 30)
        config.enable_stream(rs.stream.depth, IMG_WIDTH, IMG_HEIGHT,
                             rs.format.z16, 30)
        self.pipeline.start(config)
        self.align = rs.align(rs.stream.color)
        for _ in range(30):
            self.pipeline.wait_for_frames()

        # ===== 상태 변수 =====
        self.frame_count = 0
        self.started = False
        self.last_seen_side = None   # "left" / "right"
        self.lost_count = 0
        self.last_cx = None
        self.last_dist = None
        self.searching = False
        self.find_until = 0.0
        self.target_miss = 0

        _start_stream_server(8080)
        self.get_logger().info("MJPEG stream: http://<this-ip>:8080/stream")
        self.get_logger().info("follow_node started. target = nearest person")

        self.timer = self.create_timer(1.0 / 20.0, self.loop)
        self._fps_last_count = 0
        self._fps_last_time = time.time()
        self.fps_timer = self.create_timer(5.0, self.publish_cam_health)

    # ---------- 콜백 ----------
    def on_follow_enable(self, msg):
        self.enabled = bool(msg.data)
        if not self.enabled:
            self.stop_cmd()

    def publish_cam_health(self):
        now = time.time()
        elapsed = now - self._fps_last_time
        if elapsed <= 0:
            return
        fps = (self.frame_count - self._fps_last_count) / elapsed
        self._fps_last_count = self.frame_count
        self._fps_last_time = now
        msg = Float32()
        msg.data = float(fps)
        self.cam_health_pub.publish(msg)

    # ---------- depth ----------
    def median_depth(self, depth_frame, cx, cy, k=5):
        half = k // 2
        cx = int(min(max(cx, half), IMG_WIDTH - 1 - half))
        cy = int(min(max(cy, half), IMG_HEIGHT - 1 - half))
        vals = []
        for dx in range(-half, half + 1):
            for dy in range(-half, half + 1):
                d = depth_frame.get_distance(cx + dx, cy + dy)
                if d > 0:
                    vals.append(d)
        return float(np.median(vals)) if vals else 0.0

    # ---------- 색상 지문 ----------
    def _extract_hist(self, xyxy, img):
        x1, y1, x2, y2 = [int(v) for v in xyxy[:4]]
        h, w = img.shape[:2]
        mx = int((x2 - x1) * 0.15)
        my = int((y2 - y1) * 0.15)
        x1, y1 = max(0, x1 + mx), max(0, y1 + my)
        x2, y2 = min(w, x2 - mx), min(h, y2 - my)
        if x2 <= x1 or y2 <= y1:
            return None
        roi = img[y1:y2, x1:x2]
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        hist = cv2.calcHist([hsv], [0, 1], None, [30, 32], [0, 180, 0, 256])
        cv2.normalize(hist, hist, 0, 1, cv2.NORM_MINMAX)
        return hist

    def _update_locked_hist(self, hist):
        if hist is None:
            return
        if self.locked_hist is None:
            self.locked_hist = hist
        else:
            self.locked_hist = (self.COLOR_EMA * self.locked_hist
                                + (1.0 - self.COLOR_EMA) * hist)

    def _color_sim(self, xyxy, img):
        if self.locked_hist is None:
            return 1.0
        h = self._extract_hist(xyxy, img)
        if h is None:
            return 0.0
        return float(cv2.compareHist(
            self.locked_hist.astype("float32"),
            h.astype("float32"), cv2.HISTCMP_CORREL))

    # ---------- 임베딩 ----------
    def _extract_feat(self, xyxy, img):
        arr = np.array([xyxy[:4]], dtype=np.float32)
        feats = self.reid.get_features(arr, img)
        if feats is None or len(feats) == 0:
            return None
        f = feats[0].astype(np.float32)
        n = np.linalg.norm(f)
        return f / n if n > 0 else None

    def _extract_feats_batch(self, xyxy_list, img):
        if not xyxy_list:
            return []
        arr = np.array([b[:4] for b in xyxy_list], dtype=np.float32)
        feats = self.reid.get_features(arr, img)
        if feats is None or len(feats) == 0:
            return [None] * len(xyxy_list)
        out = []
        for i in range(len(xyxy_list)):
            if i >= len(feats):
                out.append(None)
                continue
            f = feats[i].astype(np.float32)
            n = np.linalg.norm(f)
            out.append(f / n if n > 0 else None)
        return out

    def _update_locked_feat(self, feat):
        if feat is None:
            return
        if self.locked_feat is None:
            self.locked_feat = feat
        else:
            _sim = float(np.dot(self.locked_feat, feat))
            if _sim < self.EMA_UPDATE_GATE:
                return   # 타인 의심 -> EMA 오염 차단
            self.locked_feat = (self.REID_EMA * self.locked_feat
                                + (1.0 - self.REID_EMA) * feat)
            n = np.linalg.norm(self.locked_feat)
            if n > 0:
                self.locked_feat /= n

    # ---------- 게이트 ----------
    def _gate_decide(self, sim, csim, side_block, dist_block):
        # 공간 게이트(방향/거리) 최우선: 임베딩이 높아도 위치가 어긋나면 타인
        if side_block:
            return "BLOCK(side)"
        if dist_block:
            return "BLOCK(dist)"
        if sim >= self.OSNET_STRONG:
            return "PASS(clip-strong)"
        if csim >= self.COLOR_SIM_THRESH:
            return "PASS"
        return "BLOCK"

    def _best_match_id(self, people, img):
        if self.locked_feat is None:
            return None, 0.0
        best_tid, best_sim = None, -1.0
        _feat_list = self._extract_feats_batch(
            [(p[3], p[4], p[5], p[6]) for p in people], img)
        for _pi, p in enumerate(people):
            x1, y1, x2, y2, tid = p[3], p[4], p[5], p[6], p[7]
            p_dist, p_cx = p[0], p[1]
            f = _feat_list[_pi]
            if f is None:
                continue
            sim = float(np.dot(self.locked_feat, f))
            # 가림 블랙리스트: strong이면 본인 복귀로 보고 해제, 아니면 재락 금지
            if tid in self.occlusion_blacklist:
                if sim >= self.OSNET_STRONG:
                    self.occlusion_blacklist.discard(tid)
                else:
                    continue
            # 방향 게이트
            side_block = False
            if self.last_seen_side == "left" and p_cx > CENTER_X + self.SIDE_MARGIN:
                side_block = True
            elif self.last_seen_side == "right" and p_cx < CENTER_X - self.SIDE_MARGIN:
                side_block = True
            # 거리 게이트
            dist_block = False
            if self.last_dist is not None and p_dist > 0:
                if abs(p_dist - self.last_dist) > self.DIST_GATE:
                    dist_block = True
            if side_block or dist_block:
                csim = 0.0   # 공간 탈락 확정 -> 색상 계산 생략
            else:
                csim = self._color_sim((x1, y1, x2, y2), img)
            gate = self._gate_decide(sim, csim, side_block, dist_block)
            _c = "\033[91m" if gate.startswith("BLOCK") else "\033[92m"
            self.get_logger().info(
                f"{_c}[CAND] id={tid} clip={sim:.2f} color={csim:.2f} {gate}\033[0m")
            if gate.startswith("BLOCK"):
                continue
            if sim > best_sim:
                best_sim, best_tid = sim, tid
        if best_tid is not None and best_sim >= self.REID_SIM_THRESH:
            return best_tid, best_sim
        return None, best_sim

    def pixel_to_angle(self, cx):
        cx_err = cx - CENTER_X
        return -(cx_err / IMG_WIDTH) * math.radians(HFOV_DEG)

    def publish(self, mode, distance=0.0, angle=0.0, force=False):
        if not self.enabled and not force:
            return
        msg = Twist()
        msg.linear.x = float(distance)
        msg.linear.z = float(mode)
        msg.angular.z = float(angle)
        self.cmd_pub.publish(msg)

    # ---------- 메인 루프 ----------
    def loop(self):
        global _stream_frame
        frames = self.pipeline.wait_for_frames()
        frames = self.align.process(frames)
        color = frames.get_color_frame()
        depth = frames.get_depth_frame()
        if not color or not depth:
            return
        img = np.asanyarray(color.get_data())

        if not self.enabled:
            with _stream_lock:
                _stream_frame = img.copy()
            self.frame_count += 1
            return

        # YOLO 사람 검출 (classes=[0] -> person)
        results = self.model.predict(img, classes=[0], verbose=False)
        boxes = results[0].boxes

        dets = np.empty((0, 6), dtype=np.float32)
        if len(boxes) > 0:
            xyxy = boxes.xyxy.cpu().numpy()
            conf = boxes.conf.cpu().numpy().reshape(-1, 1)
            cls = boxes.cls.cpu().numpy().reshape(-1, 1)
            dets = np.hstack([xyxy, conf, cls]).astype(np.float32)

        tracks = self.tracker.update(dets, img)   # (N,8): xyxy,id,conf,cls,idx
        annotated = img.copy()
        self.frame_count += 1

        # 워밍업
        if not self.started:
            if self.frame_count >= LOCK_FRAMES:
                self.started = True
                self.get_logger().info("[START] 추종 시작")
            with _stream_lock:
                _stream_frame = annotated.copy()
            return

        # 유효 사람 목록 (depth > 0)
        people = []
        for t in tracks:
            x1, y1, x2, y2 = map(int, t[:4])
            tid = int(t[4])
            cf = float(t[5]) if len(t) > 5 else 0.0
            cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
            dist = self.median_depth(depth, cx, cy)
            if dist > 0:
                people.append((dist, cx, cy, x1, y1, x2, y2, tid, cf))

        # 가림 블랙리스트: 화면에서 사라진 track 해제
        if self.occlusion_blacklist:
            _alive = {p[7] for p in people}
            _gone = self.occlusion_blacklist - _alive
            if _gone:
                self.occlusion_blacklist -= _gone

        distance, angle = 0.0, 0.0
        status = "SEARCHING"
        now = time.time()

        # find(재발견 정지) 유지 중
        if self.find_until > 0.0:
            if now < self.find_until:
                status = "FIND_HOLD"
                self.publish(MODE_FIND)
                self._draw_and_stream(annotated, status, 0.0, 0.0)
                return
            else:
                self.find_until = 0.0
                self.searching = not people

        if people:
            # 모든 사람 회색 박스 (타겟은 아래서 빨강 덮음)
            for _p in people:
                _d, _, _, _gx1, _gy1, _gx2, _gy2, _gtid, _gcf = _p
                _label = f"ID:{_gtid}  conf:{_gcf:.2f}  {_d:.2f}m"
                draw_fancy_box(annotated, _gx1, _gy1, _gx2, _gy2, _label,
                               (180, 180, 180), thickness=2)

            people.sort(key=lambda p: p[0])   # 가까운 순
            target = None

            if self.locked_id is None:
                # 언락: 먼저 임베딩으로 기존 타겟 재식별
                rematch_tid, sim = self._best_match_id(people, img)
                if rematch_tid is not None:
                    if rematch_tid == self._relock_cand_id:
                        self._relock_streak += 1
                    else:
                        self._relock_cand_id = rematch_tid
                        self._relock_streak = 1
                    if self._relock_streak >= self.RELOCK_STREAK:
                        self.locked_id = rematch_tid
                        target = [p for p in people if p[7] == rematch_tid][0]
                        self.get_logger().info(
                            f"[RELOCK] id={self.locked_id} sim={sim:.2f}")
                        self._relock_count += 1
                        self._relock_cand_id = None
                        self._relock_streak = 0
                    else:
                        self.get_logger().info(
                            f"[RELOCK-WAIT] id={rematch_tid} sim={sim:.2f} "
                            f"streak={self._relock_streak}/{self.RELOCK_STREAK}")
                else:
                    # 재식별 실패: 최초 1회만 새 타겟 락, 이후 대기
                    if not self.has_locked_once:
                        target = people[0]
                        self.locked_id = target[7]
                        self.locked_feat = None
                        self.locked_hist = None
                        self.has_locked_once = True
                        self.get_logger().info(f"[LOCK] target id={self.locked_id}")
                        f = self._extract_feat(target[3:7], img)
                        self._update_locked_feat(f)
                        self._update_locked_hist(self._extract_hist(target[3:7], img))
                    else:
                        target = None
                        self.get_logger().info("[WAIT] 타겟 재식별 대기 (새 사람 무시)")
            else:
                # 락: locked_id와 같은 사람만
                matched = [p for p in people if p[7] == self.locked_id]
                if matched:
                    self.target_miss = 0
                    target = matched[0]
                    if self.frame_count % 5 == 0:   # 부하: 5프레임마다 갱신
                        f = self._extract_feat(target[3:7], img)
                        self._update_locked_feat(f)
                        self._update_locked_hist(self._extract_hist(target[3:7], img))
                else:
                    people = []
                    target = None
                    alive_ids = {int(t[4]) for t in tracks}
                    if self.locked_id not in alive_ids:
                        # 가림 감지: 마지막 위치 근처 track을 블랙리스트에
                        occluders = []
                        if self.last_cx is not None and self.last_dist is not None:
                            for _t in tracks:
                                _tid = int(_t[4])
                                _tx1, _ty1, _tx2, _ty2 = map(int, _t[:4])
                                _tcx = (_tx1 + _tx2) // 2
                                _tcy = (_ty1 + _ty2) // 2
                                _td = self.median_depth(depth, _tcx, _tcy)
                                _near_cx = abs(_tcx - self.last_cx) <= self.OCC_CX_MARGIN
                                _near_d = (_td <= 0 or
                                           abs(_td - self.last_dist) <= self.OCC_DIST_MARGIN)
                                if _near_cx and _near_d:
                                    occluders.append(_tid)
                                    self.occlusion_blacklist.add(_tid)
                        if occluders:
                            self.get_logger().info(
                                f"\033[93m[OCCLUSION] id={self.locked_id} 가림 "
                                f"-> 재락금지 {occluders}\033[0m")
                        self.get_logger().info(
                            f"[UNLOCK] id={self.locked_id} track 소멸 -> 재식별 대기")
                        self._unlock_count += 1
                        self.locked_id = None
                        self.target_miss = 0

            if target is not None:
                dist, cx, cy, x1, y1, x2, y2, _tid, _tcf = target
                if self.searching:
                    self.find_until = now + FIND_HOLD_SEC
                    self.searching = False
                    self.get_logger().info("[FIND] 사람 재발견 -> 정지")
                    self.publish(MODE_FIND)
                    status = "FIND_START"
                else:
                    distance = dist
                    angle = self.pixel_to_angle(cx)
                    status = "FOLLOWING"
                    self.lost_count = 0
                    self.last_cx = cx
                    self.last_dist = dist
                    if cx < CENTER_X - 40:
                        self.last_seen_side = "left"
                    elif cx > CENTER_X + 40:
                        self.last_seen_side = "right"
                    self.publish(MODE_FOLLOW, distance, angle)

                _label = f"TARGET LOCKED  {dist:.2f}m"
                draw_fancy_box(annotated, x1, y1, x2, y2, _label,
                               (0, 0, 255), thickness=3, filled_label=True)

        if not people:
            # 사람 없음 -> 탐색
            self.lost_count += 1
            if self.lost_count >= LOST_DELAY:
                self.searching = True
                if self.last_seen_side == "right":
                    status = "SEARCH_RIGHT"
                    self.publish(MODE_SEARCH_RIGHT)
                else:
                    status = "SEARCH_LEFT"
                    self.publish(MODE_SEARCH_LEFT)
            else:
                status = "LOST_WAIT"

        self._draw_and_stream(annotated, status, distance, angle)

    def _draw_and_stream(self, annotated, status, distance, angle):
        global _stream_frame
        cv2.line(annotated, (CENTER_X, 0), (CENTER_X, IMG_HEIGHT),
                 (255, 0, 0), 1)
        cv2.putText(annotated, status, (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (102, 210, 130), 2, cv2.LINE_AA)
        cv2.putText(annotated,
                    f"dist {distance:.2f}m   ang {angle:+.3f}rad",
                    (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                    (0, 200, 255), 2, cv2.LINE_AA)
        with _stream_lock:
            _stream_frame = annotated.copy()

    def stop_cmd(self):
        try:
            for _ in range(10):
                self.publish(MODE_FIND, force=True)   # 정지
                rclpy.spin_once(self, timeout_sec=0.02)
                time.sleep(0.02)
        except Exception:
            pass

    def destroy_node(self):
        u = self._unlock_count
        r = self._relock_count
        rate = (r / u * 100.0) if u > 0 else 0.0
        self.get_logger().info(
            f"[RELOCK-STAT] relock={r} unlock={u} success_rate={rate:.1f}%")
        try:
            self.pipeline.stop()
        except Exception:
            pass
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = FollowNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("종료 - 정지 신호 발행")
        node.stop_cmd()
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
