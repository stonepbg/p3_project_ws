#!/usr/bin/env python3
import sys
import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class TtsPublisherNode(Node):
    def __init__(self):
        super().__init__('tts_publisher_node')
        
        # 'tts_message' 토픽으로 String 메시지를 발행하는 Publisher 등록 (큐 사이즈 10)
        self.publisher_ = self.create_publisher(String, 'tts_message', 10)
        
        self.get_logger().info("=== ROS 2 TTS Request Publisher Node Started ===")
        self.get_logger().info("Topic Name: /tts_message")
        self.get_logger().info("Type 'q' or press Ctrl+C to exit.")
        print("-" * 50)

    def run_interface(self):
        """사용자 입력을 받아 토픽을 실시간으로 발행하는 루프입니다."""
        while rclpy.ok():
            try:
                # 사용자로부터 m1, m2 등의 키 입력 받기
                user_input = input("발행할 TTS 명령어 입력 (예: m1, m2) : ").strip()
                
                if not user_input:
                    continue
                
                # 'q' 입력 시 종료 프로세스 진행
                if user_input.lower() == 'q':
                    print("종료 신호를 보냅니다...")
                    break
                
                # ROS 2 String 메시지 객체 생성 및 데이터 주입
                msg = String()
                msg.data = user_input
                
                # 토픽 발행
                self.publisher_.publish(msg)
                self.get_logger().info(f"🚀 [토픽 발행 완료] /tts_message -> '{msg.data}'")
                print("-" * 50)
                
            except (KeyboardInterrupt, EOFError):
                break

        # 루프를 빠져나오면 rclpy를 안전하게 종료
        rclpy.try_shutdown()

def main(args=None):
    rclpy.init(args=args)
    node = TtsPublisherNode()
    
    try:
        node.run_interface()
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()