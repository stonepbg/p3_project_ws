#!/usr/bin/env python3
import os
import sys
import time
import threading
import rclpy
from rclpy.node import Node
from gtts import gTTS
from pydub import AudioSegment

# pygame 초기화 시 오디오 드라이버 경고를 방지하기 위해 환경 변수 세팅
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame

class TtsNavigatorNode(Node):
    def __init__(self):
        super().__init__('tts_navigator_node')
        
        # tts_node.py가 실행되는 현재 터미널 경로(Current Working Directory) 기준 설정
        self.txt_file_path = os.path.join(os.getcwd(), "textmsg.txt")
        self.is_playing = False
        
        self.get_logger().info("=== ROS 2 Jazzy Auto-Split TTS Node Started ===")
        self.get_logger().info(f"Target File: {self.txt_file_path}")
        
        # 사용자 입력을 받기 위한 별도 스레드 시작
        self.input_thread = threading.Thread(target=self.menu_loop, daemon=True)
        self.input_thread.start()

    def load_messages(self):
        """textmsg.txt 파일을 실시간으로 읽어 { 'm1': '안녕하세요' } 형태의 딕셔너리로 반환합니다."""
        messages = {}
        
        if not os.path.exists(self.txt_file_path):
            with open(self.txt_file_path, "w", encoding="utf-8") as f:
                f.write("m1:안녕하세요\n")
                f.write("m2:반갑습니다.\n")
                f.write("m3:안녕히 가세요.\n")
            self.get_logger().info(f"실행 경로에 파일이 없어 기본 파일을 생성했습니다: {self.txt_file_path}")

        try:
            with open(self.txt_file_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or ":" not in line:
                        continue
                    key, msg = line.split(":", 1)
                    messages[key.strip()] = msg.strip()
        except Exception as e:
            self.get_logger().error(f"파일을 읽는 중 오류 발생: {e}")
            
        return messages

    def play_tts(self, text, voice_gender):
        """gTTS로 음성을 생성한 후, 지정된 성별 톤으로 변환해 재생합니다."""
        self.is_playing = True
        base_filename = "/tmp/ros2_base_tts.mp3"
        output_filename = "/tmp/ros2_output_tts.wav"
        
        try:
            # 1. 오리지널 고품질 구글 한국어 음성(기본 여성향) 생성
            tts = gTTS(text=text, lang='ko')
            tts.save(base_filename)
            
            # 2. pydub을 이용해 음성 파일 로드
            sound = AudioSegment.from_mp3(base_filename)
            
            # 3. 성별 구분에 따른 피치 조절 작업 진행
            if voice_gender == 'm':
                # [남성 변환] 샘플 레이트를 변경하여 굵고 묵직한 남성 톤 생성
                low_pitch_sample_rate = int(sound.frame_rate * 0.78)
                modified_sound = sound._spawn(sound.raw_data, overrides={'frame_rate': low_pitch_sample_rate})
                # 속도를 원본 데이터 비율에 맞게 재조정 (1.25배속)
                modified_sound = modified_sound.speedup(playback_speed=1.25)
                self.get_logger().info(f"🔊 [남성 보이스 재생] '{text}'")
            else:
                # [여성 변환] gTTS 기본 맑은 톤 사용 (자연스러운 1.1배속 조절)
                modified_sound = sound.speedup(playback_speed=1.1)
                self.get_logger().info(f"🔊 [여성 보이스 재생] '{text}'")
                
            # 4. 변조된 오디오를 임시 wav 파일로 저장
            modified_sound.export(output_filename, format="wav")
            
            # 5. pygame 오디오 플레이어로 재생
            pygame.mixer.init()
            pygame.mixer.music.load(output_filename)
            pygame.mixer.music.play()
            
            while pygame.mixer.music.get_busy() and rclpy.ok():
                time.sleep(0.1)
                
            pygame.mixer.music.unload()
            pygame.mixer.quit()
            
        except Exception as e:
            self.get_logger().error(f"TTS 제어 및 재생 실패: {e}")
        finally:
            # 잔여 임시 파일 청소
            for path in [base_filename, output_filename]:
                if os.path.exists(path):
                    try:
                        os.remove(path)
                    except Exception:
                        pass
            self.is_playing = False

    def menu_loop(self):
        """사용자 터미널 입력을 처리하는 루프입니다."""
        time.sleep(0.5)
        
        while rclpy.ok():
            if self.is_playing:
                time.sleep(0.2)
                continue
                
            # 오리지널 텍스트 파일 불러오기 (m1, m2, m3)
            raw_msg_dict = self.load_messages()
            
            # 화면 표시용 및 내부 명령어 매핑용 딕셔너리 동적 생성 (m1_f, m1_m 등)
            display_menu = {}
            for key, value in raw_msg_dict.items():
                display_menu[f"{key}_f"] = (value, 'f', "(여성)")
                display_menu[f"{key}_m"] = (value, 'm', "(남성)")
            
            print("\n" + "="*40)
            print(" [ ROS 2 TTS MENU ]")
            print("="*40)
            # 알파벳 및 숫자 정렬 순서대로 메뉴 출력 (m1_f, m1_m, m2_f, m2_m...)
            for display_key in sorted(display_menu.keys()):
                text_val, gender, gender_txt = display_menu[display_key]
                print(f"  * {display_key}: {text_val} {gender_txt}")
            print("  * q: 노드 종료 (Quit)")
            print("="*40)
            
            try:
                choice = input("원하는 명령어를 입력하세요 (예: m1_f 또는 m1_m): ").strip()
            except EOFError:
                break
                
            if choice.lower() == 'q':
                print("종료 신호를 보냅니다...")
                break
                
            if choice in display_menu:
                # 선택된 메뉴 정보 추출
                selected_text, gender, _ = display_menu[choice]
                
                # 스핀 흐름에 영향을 주지 않도록 별도 스레드로 재생 실행
                play_thread = threading.Thread(
                    target=self.play_tts, 
                    args=(selected_text, gender), 
                    daemon=True
                )
                play_thread.start()
                
                while play_thread.is_alive():
                    time.sleep(0.1)
            else:
                print("❌ 등록되지 않은 키입니다. 메뉴를 다시 확인해 주세요.")
                time.sleep(0.8)
                
        sys.exit(0)

def main(args=None):
    rclpy.init(args=args)
    node = TtsNavigatorNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()