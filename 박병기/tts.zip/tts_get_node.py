#!/usr/bin/env python3
import os
import sys
import time
import threading
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from gtts import gTTS
from pydub import AudioSegment

# pygame 초기화 시 오디오 드라이버 경고를 방지하기 위해 환경 변수 세팅
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame

class TtsNavigatorNode(Node):
    def __init__(self):
        super().__init__('tts_navigator_node')
        
        # 실행 경로 기준 파일 설정
        self.txt_file_path = os.path.join(os.getcwd(), "textmsg.txt")
        self.is_playing = False
        self.running = True  # 스레드 종료 플래그
        
        self.last_mtime = 0
        self.current_menu = {}
        
        # Pygame 믹서 초기화
        try:
            pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
        except Exception as e:
            self.get_logger().error(f"Pygame Mixer 초기화 실패: {e}")

        self.get_logger().info("=== ROS 2 Jazzy Fixed-Pitch Korean TTS Node Started ===")
        self.get_logger().info(f"Target File: {self.txt_file_path}")
        
        # 'tts_message' 토픽 구독자 설정 (큐 사이즈 10)
        self.subscription = self.create_subscription(
            String,
            'tts_message',
            self.topic_callback,
            10
        )
        self.get_logger().info("Subscribed to topic: /tts_message")
        
        # 파일 변경을 실시간으로 감시하는 스레드만 시작
        self.watcher_thread = threading.Thread(target=self.file_watcher_loop, daemon=True)
        self.watcher_thread.start()
        
        # 초기 메뉴 로드 및 안내 출력
        self.current_menu = self.load_messages()
        self.print_ready_status()

    def load_messages(self):
        """textmsg.txt 파일을 읽어 딕셔너리로 반환합니다."""
        messages = {}
        if not os.path.exists(self.txt_file_path):
            with open(self.txt_file_path, "w", encoding="utf-8") as f:
                f.write("m1:안녕 친구\n")
                f.write("m2:반가워 친구\n")
                f.write("m3:잘가 친구\n")
            self.get_logger().info(f"기본 파일을 생성했습니다: {self.txt_file_path}")

        try:
            with open(self.txt_file_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or ":" not in line:
                        continue
                    key, msg = line.split(":", 1)
                    messages[key.strip()] = msg.strip()
        except Exception as e:
            self.get_logger().error(f"파일을 읽는 중 오류 발생: {e}")
            
        return messages

    def file_watcher_loop(self):
        """textmsg.txt 파일의 수정 시간을 감시하여 내용이 바뀌면 데이터를 동적 갱신합니다."""
        while rclpy.ok() and self.running:
            if os.path.exists(self.txt_file_path):
                try:
                    mtime = os.path.getmtime(self.txt_file_path)
                    if mtime != self.last_mtime:
                        self.last_mtime = mtime
                        self.current_menu = self.load_messages()
                        if self.last_mtime != 0:
                            print("\n🔄 [알림] textmsg.txt 파일 변경이 감지되어 메시지 데이터가 업데이트되었습니다.")
                            self.print_ready_status()
                except Exception:
                    pass
            time.sleep(1.0)

    def topic_callback(self, msg):
        """/tts_message 토픽으로 들어온 문자열을 받아 여성 TTS로 재생합니다."""
        choice = msg.data.strip()
        
        if self.is_playing:
            self.get_logger().warn(f"⚠️ 현재 다른 음성이 재생 중이므로 토픽 요청('{choice}')을 무시합니다.")
            return

        if choice in self.current_menu:
            selected_text = self.current_menu[choice]
            self.get_logger().info(f"📥 [토픽 수신] 명령어: '{choice}' -> 재생 시작")
            
            # 재생 루프가 스핀을 블로킹하지 않도록 별도 스레드 구동
            play_thread = threading.Thread(
                target=self.play_tts, 
                args=(selected_text,), 
                daemon=True
            )
            play_thread.start()
        else:
            self.get_logger().error(f"❌ [토픽 에러] textmsg.txt에 '{choice}' 키가 없습니다.")

    def play_tts(self, text):
        """여성 보이스 고정 알고리즘을 적용하여 안정적으로 재생합니다."""
        self.is_playing = True
        base_filename = "/tmp/ros2_base_korean.mp3"
        output_filename = "/tmp/ros2_output_korean.wav"
        
        try:
            tts = gTTS(text=text, lang='ko')
            tts.save(base_filename)
            
            sound = AudioSegment.from_mp3(base_filename)
            high_rate = int(sound.frame_rate * 1.10)
            modified_sound = sound._spawn(sound.raw_data, overrides={'frame_rate': high_rate})
            modified_sound = modified_sound.set_frame_rate(44100)
            modified_sound = modified_sound.speedup(playback_speed=0.91, chunk_size=150, crossfade=25)
            
            self.get_logger().info(f"🔊 [재생 중] '{text}'")
            modified_sound.export(output_filename, format="wav")
            
            pygame.mixer.music.set_volume(1.0)
            pygame.mixer.music.load(output_filename)
            pygame.mixer.music.play()
            
            while pygame.mixer.music.get_busy() and rclpy.ok() and self.running:
                time.sleep(0.1)
                
            pygame.mixer.music.unload()
            
        except Exception as e:
            self.get_logger().error(f"TTS 재생 오류: {e}")
        finally:
            for path in [base_filename, output_filename]:
                if os.path.exists(path):
                    try:
                        os.remove(path)
                    except Exception:
                        pass
            self.is_playing = False
            self.print_ready_status()

    def print_ready_status(self):
        """대기 상태를 알리는 심플한 안내창을 출력합니다."""
        print("\n" + "="*40)
        print(" [ ROS 2 REAL-TIME TTS NODE - READY ]")
        print("="*40)
        print("  * 원격 토픽 명령을 기다리는 중입니다...")
        print("  * 종료하려면 이 터미널창에서 Ctrl + C를 누르세요.")
        print("="*40)

def main(args=None):
    rclpy.init(args=args)
    node = TtsNavigatorNode()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
        pass
    finally:
        node.running = False
        try:
            pygame.mixer.quit()
        except:
            pass
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()